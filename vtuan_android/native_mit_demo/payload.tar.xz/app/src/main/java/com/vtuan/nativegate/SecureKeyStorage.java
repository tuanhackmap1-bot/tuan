package com.vtuan.nativegate;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** AES-256-GCM credential storage, supported by Android 6+. No plaintext preferences. */
public final class SecureKeyStorage {
    private static final String ALIAS="vtuan.native.gate.aes.v1";
    private static final String PREF="vtuan_native_gate_secure";
    private final SharedPreferences prefs;

    public SecureKeyStorage(Context context) {
        prefs=context.getApplicationContext().getSharedPreferences(PREF,Context.MODE_PRIVATE);
    }
    private static SecretKey secret() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (!ks.containsAlias(ALIAS)) {
            KeyGenerator generator=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
            generator.init(new KeyGenParameterSpec.Builder(ALIAS,
                KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build());
            generator.generateKey();
        }
        return (SecretKey)ks.getKey(ALIAS,null);
    }
    public synchronized void save(String value) throws Exception {
        if (value==null || value.trim().isEmpty()) throw new IllegalArgumentException("empty key");
        Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE,secret());
        byte[] enc=c.doFinal(value.getBytes(StandardCharsets.UTF_8));
        prefs.edit().putString("iv",Base64.encodeToString(c.getIV(),Base64.NO_WRAP))
            .putString("cipher",Base64.encodeToString(enc,Base64.NO_WRAP)).apply();
    }
    public synchronized String load() {
        String iv=prefs.getString("iv",null),ciphertext=prefs.getString("cipher",null);
        if(iv==null||ciphertext==null)return null;
        try {
            byte[] ivBytes=Base64.decode(iv,Base64.NO_WRAP);
            if(ivBytes.length!=12)throw new IllegalArgumentException("Invalid GCM iv");
            Cipher c=Cipher.getInstance("AES/GCM/NoPadding");
            c.init(Cipher.DECRYPT_MODE,secret(),new GCMParameterSpec(128,ivBytes));
            byte[] raw=c.doFinal(Base64.decode(ciphertext,Base64.NO_WRAP));
            return new String(raw,StandardCharsets.UTF_8);
        } catch(Exception e){clear();return null;}
    }
    public synchronized void clear(){prefs.edit().remove("iv").remove("cipher").apply();}
}
