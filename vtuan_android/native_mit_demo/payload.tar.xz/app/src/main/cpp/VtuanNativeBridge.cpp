// VTUAN gate native bridge. This file is original code, not the closed ADROI binary.
// Compile it with the editable ImGui native source and call vtuan::authorized()
// before showing the menu AND before executing each gated operation.
#include <jni.h>
#include <atomic>

namespace vtuan {
static std::atomic<bool> g_authorized{false};
bool authorized() noexcept {
    return g_authorized.load(std::memory_order_acquire);
}
}

extern "C" JNIEXPORT void JNICALL
Java_com_vtuan_nativegate_VtuanNativeBridge_setAuthorized(JNIEnv*, jclass, jboolean yes) {
    vtuan::g_authorized.store(yes == JNI_TRUE, std::memory_order_release);
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_vtuan_nativegate_VtuanNativeBridge_isAuthorized(JNIEnv*, jclass) {
    return vtuan::authorized() ? JNI_TRUE : JNI_FALSE;
}
