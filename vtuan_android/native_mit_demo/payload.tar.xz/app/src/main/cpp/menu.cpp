// VTUAN native menu renderer — proof of JNI + live key gating.
// Does not modify, hook, or read any third-party game.
#include <jni.h>
#include <GLES3/gl3.h>
#include "imgui.h"
#include "backends/imgui_impl_opengl3.h"
#include "VtuanNativeBridge.h"

namespace {
  bool initialized=false;
  bool demoOption=false;
  int frames=0;
  int screenW=1280,screenH=720;
  void shutdown(){
    if(!initialized) return;
    ImGui_ImplOpenGL3_Shutdown();
    ImGui::DestroyContext();
    initialized=false;
  }
}
extern "C" JNIEXPORT void JNICALL
Java_com_vtuan_nativeproof_NativeSurface_nativeInit(JNIEnv*,jclass){
    shutdown();
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io=ImGui::GetIO();
    io.IniFilename=nullptr;
    io.DisplaySize=ImVec2(static_cast<float>(screenW),static_cast<float>(screenH));
    ImGui::StyleColorsDark();
    ImGuiStyle& s=ImGui::GetStyle();
    s.WindowRounding=15.0f; s.FrameRounding=10.0f;
    s.Colors[ImGuiCol_TitleBgActive]=ImVec4(.36f,.13f,.52f,1.f);
    s.Colors[ImGuiCol_Button]=ImVec4(.61f,.19f,.79f,1.f);
    s.Colors[ImGuiCol_ButtonHovered]=ImVec4(.74f,.32f,.95f,1.f);
    s.Colors[ImGuiCol_CheckMark]=ImVec4(.84f,.50f,1.f,1.f);
    ImGui_ImplOpenGL3_Init("#version 300 es");
    initialized=true;
}
extern "C" JNIEXPORT void JNICALL
Java_com_vtuan_nativeproof_NativeSurface_nativeResize(JNIEnv*,jclass,jint width,jint height){
    if(width>0)screenW=width;
    if(height>0)screenH=height;
    glViewport(0,0,screenW,screenH);
}
extern "C" JNIEXPORT void JNICALL
Java_com_vtuan_nativeproof_NativeSurface_nativeTouch(JNIEnv*,jclass,jfloat x,jfloat y,jboolean down){
    if(!initialized)return;
    ImGuiIO& io=ImGui::GetIO();
    io.AddMousePosEvent(x,y);
    io.AddMouseButtonEvent(0,down==JNI_TRUE);
}
extern "C" JNIEXPORT void JNICALL
Java_com_vtuan_nativeproof_NativeSurface_nativeFrame(JNIEnv*,jclass){
    glViewport(0,0,screenW,screenH);
    glClearColor(.055f,.035f,.08f,1.f);
    glClear(GL_COLOR_BUFFER_BIT);
    if(!initialized||!vtuan::authorized())return;
    ImGuiIO& io=ImGui::GetIO();
    io.DisplaySize=ImVec2((float)screenW,(float)screenH);
    io.DeltaTime=1.f/60.f;
    ImGui_ImplOpenGL3_NewFrame();
    ImGui::NewFrame();
    ImGui::SetNextWindowSize(ImVec2(530,340),ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowPos(ImVec2((screenW-530.f)/2.f,(screenH-340.f)/2.f),ImGuiCond_FirstUseEver);
    ImGui::Begin("VTUAN NATIVE MENU",nullptr,ImGuiWindowFlags_NoCollapse);
    ImGui::TextColored(ImVec4(.86f,.52f,1.f,1.f),"AUTHENTICATED: VTUAN KEY");
    ImGui::Separator();
    ImGui::TextWrapped("Real C++ / OpenGL ES3 / Dear ImGui UI. This is a test application, NOT a Liên Quân mod.");
    ImGui::Spacing();
    ImGui::Checkbox("Enable demo drawing",&demoOption);
    ImGui::Text("Rendered frames: %d",++frames);
    ImGui::TextDisabled("ESP/AIM/Game hooks: not implemented");
    if(demoOption){
      ImGui::GetForegroundDrawList()->AddCircle(ImVec2(screenW*.78f,screenH*.5f),78.f,IM_COL32(206,121,245,220),96,4.f);
    }
    ImGui::End();
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
}
extern "C" JNIEXPORT void JNICALL
Java_com_vtuan_nativeproof_NativeSurface_nativeShutdown(JNIEnv*,jclass){shutdown();}
