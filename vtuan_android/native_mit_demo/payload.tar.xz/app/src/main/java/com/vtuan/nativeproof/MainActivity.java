package com.vtuan.nativeproof;
import android.app.Activity;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import com.vtuan.nativegate.VtuanMenuController;
import com.vtuan.nativegate.VtuanNativeBridge;

public final class MainActivity extends Activity implements VtuanMenuController.Listener {
    static {System.loadLibrary("vtuanmenu");}
    private VtuanMenuController gate;
    private LinearLayout login;
    private TextView status;
    private EditText input;
    private CheckBox remember;
    private NativeSurface surface;
    private boolean resumed=false;
    private int dp(float val){return Math.round(val*getResources().getDisplayMetrics().density);}
    private GradientDrawable box(int bg,int stroke,int r){
        GradientDrawable g=new GradientDrawable();g.setColor(bg);g.setCornerRadius(dp(r));
        if(stroke!=0)g.setStroke(dp(1),stroke);return g;
    }
    private TextView label(String s,int size,boolean bold){
        TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);
        if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setGravity(Gravity.CENTER);return t;
    }
    private LinearLayout.LayoutParams row(int h){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,h<0?h:dp(h));p.topMargin=dp(9);return p;
    }
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        gate=new VtuanMenuController(this,"https://vtuan-103-159-51-231.sslip.io",this);
        showLogin("Nhập key VTUAN để thử menu native");
    }
    private void showLogin(String message){
        if(surface!=null){surface.onPause();surface=null;}
        FrameLayout root=new FrameLayout(this);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
          new int[]{0xff13101e,0xff271634,0xff0f0c1d}));
        login=new LinearLayout(this);login.setOrientation(1);login.setPadding(dp(20),dp(16),dp(20),dp(16));
        login.setBackground(box(0xff2b1e3a,0xffb76fee,17));
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(dp(420),-2,Gravity.CENTER);
        lp.width=Math.min(dp(420),getResources().getDisplayMetrics().widthPixels-dp(24));
        root.addView(login,lp);
        login.addView(label("CHÀO MỪNG BẠN ĐẾN VỚI VTUAN",15,true),row(35));
        input=new EditText(this);input.setHint("Điền key vào đây");input.setHintTextColor(0xffc6a3d7);
        input.setTextColor(-1);input.setSingleLine(true);input.setTextSize(13);
        input.setBackground(box(0xff4d3461,0xffb96be8,22));input.setPadding(dp(14),0,dp(14),0);
        login.addView(input,row(46));
        remember=new CheckBox(this);remember.setText("Lưu Key an toàn trên máy");remember.setChecked(true);
        remember.setTextColor(-1);login.addView(remember,row(40));
        LinearLayout controls=new LinearLayout(this);controls.setOrientation(0);
        Button submit=new Button(this);submit.setText("Xác nhận");submit.setTextColor(-1);
        submit.setAllCaps(false);submit.setBackground(box(0xffa83bed,0,20));
        Button paste=new Button(this);paste.setText("Dán key");paste.setTextColor(-1);
        paste.setAllCaps(false);paste.setBackground(box(0xff7436aa,0,20));
        LinearLayout.LayoutParams first=new LinearLayout.LayoutParams(0,dp(44),1);first.rightMargin=dp(8);
        controls.addView(submit,first);controls.addView(paste,new LinearLayout.LayoutParams(0,dp(44),1));
        login.addView(controls,row(44));
        status=label(message,12,false);login.addView(status,row(40));
        setContentView(root);
        submit.setOnClickListener(v->{status.setText("Đang xác thực HTTPS...");gate.activate(input.getText().toString().trim(),remember.isChecked());});
        paste.setOnClickListener(v->{
            ClipboardManager c=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            if(c!=null&&c.hasPrimaryClip()){
                CharSequence x=c.getPrimaryClip().getItemAt(0).coerceToText(this);
                if(x!=null)input.setText(x.toString().trim());
            }
        });
    }
    @Override public void showKeyPrompt(String notice){
        if(isFinishing())return;
        if(surface!=null||status==null)showLogin(notice);
        else status.setText(notice);
    }
    @Override public void keyValidated(String expires){
        if(surface!=null||!resumed)return;
        surface=new NativeSurface(this);
        setContentView(surface);
        surface.onResume();
    }
    @Override public void onResume(){super.onResume();resumed=true;gate.onResume();if(surface!=null)surface.onResume();}
    @Override public void onPause(){resumed=false;gate.onPause();if(surface!=null)surface.onPause();super.onPause();}
    @Override public void onDestroy(){gate.close();super.onDestroy();}
}
