package com.vtuan.nativegate;

import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * VTUAN V10 key contract. First successful /api/activate starts the duration.
 * Later /api/verify detects expiry/revocation. No HWID is collected or sent.
 */
public final class VtuanKeyClient {
    private final String root;
    public VtuanKeyClient(String httpsBase) {
        if(httpsBase==null || !httpsBase.matches("https://[A-Za-z0-9.:-]+/?"))
            throw new IllegalArgumentException("A single HTTPS host is required");
        root=httpsBase.replaceAll("/+$", "");
    }
    public Result activate(String key) throws Exception {return send("/api/activate",key);}
    public Result verify(String key) throws Exception {return send("/api/verify",key);}
    private Result send(String path,String key) throws Exception {
        if(key==null||key.length()<8||key.length()>160) return new Result(false,"Key không hợp lệ", "");
        HttpURLConnection conn=(HttpURLConnection)new URL(root+path).openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(8000);conn.setReadTimeout(8000);
        conn.setInstanceFollowRedirects(false);
        conn.setUseCaches(false);
        conn.setRequestProperty("Content-Type","application/json; charset=utf-8");
        conn.setRequestProperty("Accept","application/json");
        conn.setDoOutput(true);
        JSONObject payload=new JSONObject();payload.put("key",key);
        try {
            byte[] bytes=payload.toString().getBytes(StandardCharsets.UTF_8);
            try(OutputStream out=conn.getOutputStream()){out.write(bytes);}
            int status=conn.getResponseCode();
            if(status>=300&&status<400) return new Result(false,"Không cho phép chuyển hướng HTTP","");
            InputStream stream=(status>=200&&status<300)?conn.getInputStream():conn.getErrorStream();
            if(stream==null)return new Result(false,"Máy chủ không trả dữ liệu","");
            StringBuilder raw=new StringBuilder();
            try(BufferedReader reader=new BufferedReader(new InputStreamReader(stream,StandardCharsets.UTF_8))) {
                String line;
                while((line=reader.readLine())!=null) {
                    raw.append(line);
                    if(raw.length()>16_384)throw new IllegalStateException("Server response too large");
                }
            }
            JSONObject body=new JSONObject(raw.toString());
            boolean valid=status==200&&body.optBoolean("ok",false);
            String message=body.optString("message", valid?"Key hợp lệ":"Key không hợp lệ");
            return new Result(valid,message,valid?body.optString("expires_at",""):"");
        } finally {conn.disconnect();}
    }
    public static final class Result {
        public final boolean ok;
        public final String message;
        public final String expiresAt;
        Result(boolean ok,String message,String expiresAt){this.ok=ok;this.message=message;this.expiresAt=expiresAt;}
    }
}
