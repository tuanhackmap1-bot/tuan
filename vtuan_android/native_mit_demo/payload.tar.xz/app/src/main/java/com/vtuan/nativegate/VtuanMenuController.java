package com.vtuan.nativegate;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Menu is CLOSED by default and after any failed network/expired-key check.
 * Requires the licensed host application's own loaded JNI menu library.
 * Do not invoke verify from the UI thread; native permission is always reset
 * while a verification is in progress.
 */
public final class VtuanMenuController implements AutoCloseable {
    public interface Listener {
        void showKeyPrompt(String notice);
        void keyValidated(String expiresAt);
    }
    private final Activity activity;
    private final SecureKeyStorage store;
    private final VtuanKeyClient client;
    private final Listener listener;
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private final Handler main=new Handler(Looper.getMainLooper());
    private static final long RECHECK_MS=60_000;
    private boolean closed=false;
    private boolean resumed=false;
    private String sessionKey=null;
    private int epoch=0;
    private final Runnable periodic=new Runnable(){
        @Override public void run() {
            if(closed)return;
            verifyStored();
            main.postDelayed(this,RECHECK_MS);
        }
    };

    public VtuanMenuController(Activity activity,String server,Listener listener) {
        this.activity=activity;this.listener=listener;
        this.store=new SecureKeyStorage(activity);
        this.client=new VtuanKeyClient(server);
        VtuanNativeBridge.setAuthorized(false);
    }
    /** Host Activity.onResume() - reverify after any background activity. */
    public void onResume(){
        if(closed)return;
        resumed=true; epoch++;
        main.removeCallbacks(periodic);
        periodic.run();
    }
    /** Host Activity.onPause() - stop gating whenever app is inactive. */
    public void onPause(){
        resumed=false; epoch++;
        main.removeCallbacks(periodic);
        VtuanNativeBridge.setAuthorized(false);
    }
    public void activate(String key,boolean remember) {
        if(closed || !resumed)return;
        final int requestEpoch=++epoch;
        VtuanNativeBridge.setAuthorized(false);
        executor.execute(()-> {
            try{
                VtuanKeyClient.Result result=client.activate(key);
                if(closed)return;
                main.post(()->{
                    if(closed||!resumed||requestEpoch!=epoch)return;
                    if(result.ok){
                        try{if(remember)store.save(key);else store.clear();sessionKey=key;}
                        catch(Exception e){store.clear();listener.showKeyPrompt("Key hợp lệ nhưng không lưu được an toàn");return;}
                        VtuanNativeBridge.setAuthorized(true);
                        listener.keyValidated(result.expiresAt);
                    }else{
                        VtuanNativeBridge.setAuthorized(false);
                        listener.showKeyPrompt(result.message);
                    }
                });
            }catch(Exception e){fail("Không kết nối được máy chủ VTUAN",requestEpoch);}
        });
    }
    private void verifyStored(){
        if(closed||!resumed)return;
        final int requestEpoch=epoch;
        VtuanNativeBridge.setAuthorized(false);
        final String key=sessionKey!=null?sessionKey:store.load();
        if(key==null){listener.showKeyPrompt("Nhập key VTUAN");return;}
        executor.execute(()->{
            try{
                VtuanKeyClient.Result result=client.verify(key);
                main.post(()->{
                    if(closed||!resumed||requestEpoch!=epoch)return;
                    if(result.ok){
                        VtuanNativeBridge.setAuthorized(true);
                        listener.keyValidated(result.expiresAt);
                    }else{
                        store.clear();sessionKey=null;
                        VtuanNativeBridge.setAuthorized(false);
                        listener.showKeyPrompt(result.message);
                    }
                });
            }catch(Exception e){fail("Mất kết nối máy chủ VTUAN, menu đã khóa",requestEpoch);}
        });
    }
    private void fail(String error,int requestEpoch){main.post(()->{
        if(closed||!resumed||epoch!=requestEpoch)return;
        VtuanNativeBridge.setAuthorized(false);
        listener.showKeyPrompt(error);
    });}
    @Override public void close(){
        closed=true; resumed=false; sessionKey=null; epoch++;
        main.removeCallbacks(periodic);
        VtuanNativeBridge.setAuthorized(false);
        executor.shutdownNow();
    }
}
