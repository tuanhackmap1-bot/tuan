package com.vtuan.nativegate;

/**
 * Compile the JNI implementation in the SAME already-loaded native menu library.
 * The host app must call System.loadLibrary(<menu-lib-name>) before this method.
 */
public final class VtuanNativeBridge {
    private VtuanNativeBridge() { }
    public static native void setAuthorized(boolean allowed);
    public static native boolean isAuthorized();
}
