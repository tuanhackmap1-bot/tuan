// MinDo RootHide overlay bridge (experimental).
// Visual menu controlling the existing, licensed MinDo patch through bolacfg.bin.
// It does NOT implement or distribute Aim/ESP logic or bypass license.
// Build target: iOS 16+, RootHide-compatible Theos. Not tested on a device.
typedef long long int64_t;
typedef unsigned long long uint64_t;
typedef unsigned long size_t;
extern int snprintf(char *, size_t, const char *, ...);
#define NULL ((void *)0)

typedef void *id;
typedef void *Class;
typedef void *SEL;
typedef struct { double x,y; } CGPoint;
typedef struct { double width,height; } CGSize;
typedef struct { CGPoint origin; CGSize size; } CGRect;
struct objc_super { id receiver; Class super_class; };

extern Class objc_getClass(const char *);
extern Class objc_allocateClassPair(Class, const char *, size_t);
extern void objc_registerClassPair(Class);
extern int class_addMethod(Class, SEL, void *, const char *);
extern SEL sel_registerName(const char *);
extern Class object_getClass(id);
extern id objc_msgSend(id, SEL, ...);
extern id objc_msgSendSuper2(struct objc_super *, SEL, ...);
extern int64_t dispatch_time(uint64_t, int64_t);
extern void dispatch_after_f(int64_t, void *, void *, void (*)(void *));
extern void _dispatch_main_q;
extern double CFAbsoluteTimeGetCurrent(void);
extern id NSHomeDirectory(void);

#define SELN(name) sel_registerName(name)
#define CLASS(name) ((id)objc_getClass(name))
#define OBJ0(o,n) ((id(*)(id,SEL))objc_msgSend)(o,SELN(n))
#define OBJ1(o,n,a) ((id(*)(id,SEL,id))objc_msgSend)(o,SELN(n),(id)(a))
#define VOID0(o,n) ((void(*)(id,SEL))objc_msgSend)(o,SELN(n))
#define VOID1(o,n,a) ((void(*)(id,SEL,id))objc_msgSend)(o,SELN(n),(id)(a))
#define BOOL1(o,n,a) ((void(*)(id,SEL,int))objc_msgSend)(o,SELN(n),a)
#define LONG1(o,n,a) ((void(*)(id,SEL,long))objc_msgSend)(o,SELN(n),a)
#define DOUBLE1(o,n,a) ((void(*)(id,SEL,double))objc_msgSend)(o,SELN(n),a)

static id gWindow, gRoot, gPanel, gFloating, gFpsLabel, gFpsButton, gTarget;
static id gReticle, gReticleButton;
static id gCfgStatus, gAimBtn, gBoxBtn, gLineBtn, gBoneBtn;
static unsigned char gCfg[24];
static int gCfgValid=0;
static int gShowReticle=0;
static int gShowFps=1;
static unsigned long gFrames=0;
static double gLast=0;
static unsigned gAttempts=0;

static id str(const char *c){ return ((id(*)(id,SEL,const char*))objc_msgSend)(CLASS("NSString"),SELN("stringWithUTF8String:"),c); }
static CGRect rect(double x,double y,double w,double h){ CGRect r={{x,y},{w,h}}; return r; }
static void frame(id v,CGRect r){ ((void(*)(id,SEL,CGRect))objc_msgSend)(v,SELN("setFrame:"),r); }
static CGRect bounds(id v){ return ((CGRect(*)(id,SEL))objc_msgSend)(v,SELN("bounds")); }
static id color(double r,double g,double b,double a){ return ((id(*)(id,SEL,double,double,double,double))objc_msgSend)(CLASS("UIColor"),SELN("colorWithRed:green:blue:alpha:"),r,g,b,a); }
static id font(double pt,int bold){ return ((id(*)(id,SEL,double))objc_msgSend)(CLASS("UIFont"),SELN(bold?"boldSystemFontOfSize:":"systemFontOfSize:"),pt); }
static id view(CGRect r,id bg,double corner){id v=OBJ0(CLASS("UIView"),"new");frame(v,r); if(bg)VOID1(v,"setBackgroundColor:",bg); if(corner>0){id layer=OBJ0(v,"layer");DOUBLE1(layer,"setCornerRadius:",corner);BOOL1(layer,"setMasksToBounds:",1);}return v;}
static id label(const char *text,CGRect r,double pt,id txtcolor,int alignment){id v=OBJ0(CLASS("UILabel"),"new");frame(v,r);VOID1(v,"setText:",str(text));VOID1(v,"setFont:",font(pt,0));VOID1(v,"setTextColor:",txtcolor);LONG1(v,"setTextAlignment:",alignment);LONG1(v,"setNumberOfLines:",0);return v;}
static id button(const char *name,CGRect r,id bg, const char *action){id b=((id(*)(id,SEL,long))objc_msgSend)(CLASS("UIButton"),SELN("buttonWithType:"),0);frame(b,r);VOID1(b,"setBackgroundColor:",bg);((void(*)(id,SEL,id,long))objc_msgSend)(b,SELN("setTitle:forState:"),str(name),0);((void(*)(id,SEL,id,long))objc_msgSend)(b,SELN("setTitleColor:forState:"),color(1,1,1,1),0);VOID1(OBJ0(b,"titleLabel"),"setFont:",font(13,1)); DOUBLE1(OBJ0(b,"layer"),"setCornerRadius:",10); ((void(*)(id,SEL,id,SEL,unsigned long))objc_msgSend)(b,SELN("addTarget:action:forControlEvents:"),gTarget,SELN(action),64); return b;}

static id hitTest(id self,SEL cmd,CGPoint p,id event){
    (void)cmd;
    struct objc_super sup={self, object_getClass(self)};
    id hit=((id(*)(struct objc_super*,SEL,CGPoint,id))objc_msgSendSuper2)(&sup, SELN("hitTest:withEvent:"),p,event);
    return (hit==self||hit==gRoot)?NULL:hit;
}
// bolacfg.bin: match AppModel.swift payload encoding and CRC.
// Read from the currently running game's own Documents container only.
static id cfgPath(void){
    id home=NSHomeDirectory();
    if(!home)return NULL;
    return OBJ1(home,"stringByAppendingPathComponent:",str("Documents/bolacfg.bin"));
}
static unsigned int cfgCRC(const unsigned char *b,unsigned long n){
    unsigned int crc=0xFFFFFFFFu;
    for(unsigned long i=0;i<n;i++){
        crc^=(unsigned int)b[i];
        for(int k=0;k<8;k++)crc=(crc>>1)^((crc&1)?0xEDB88320u:0);
    }
    return ~crc;
}
static void cfgEncode(unsigned char out[28],const unsigned char in[24]){
    for(int i=0;i<24;i++)out[i]=in[i]^((unsigned char)((0x5A+i*0x37)^(i<<4)));
    unsigned int crc=cfgCRC(out,24);
    for(int i=0;i<4;i++)out[24+i]=(unsigned char)((crc>>(8*i))&0xff);
}
static int cfgRead(void){
    id p=cfgPath();
    if(!p)return 0;
    id d=OBJ1(CLASS("NSData"),"dataWithContentsOfFile:",p);
    if(!d)return 0;
    unsigned long n=((unsigned long(*)(id,SEL))objc_msgSend)(d,SELN("length"));
    if(n!=28)return 0;
    unsigned char raw[28];
    ((void(*)(id,SEL,void*,unsigned long))objc_msgSend)(d,SELN("getBytes:length:"),raw,28);
    unsigned int exp=0;
    for(int i=0;i<4;i++)exp|=((unsigned int)raw[24+i])<<(8*i);
    if(cfgCRC(raw,24)!=exp)return 0;
    for(int i=0;i<24;i++)gCfg[i]=raw[i]^((unsigned char)((0x5A+i*0x37)^(i<<4)));
    if(gCfg[0]!='B'||gCfg[1]!='O'||gCfg[2]!='L'||gCfg[3]!='A'||gCfg[4]!=1)return 0;
    return 1;
}
static int cfgWrite(void){
    if(!gCfgValid)return 0;
    id p=cfgPath();
    if(!p)return 0;
    unsigned char out[28];
    cfgEncode(out,gCfg);
    id d=((id(*)(id,SEL,const void*,unsigned long))objc_msgSend)(CLASS("NSData"),SELN("dataWithBytes:length:"),out,28);
    if(!d)return 0;
    return ((int(*)(id,SEL,id,int))objc_msgSend)(d,SELN("writeToFile:atomically:"),p,1)!=0;
}
static void setBtnTitle(id b,const char *s){
    if(b) ((void(*)(id,SEL,id,long))objc_msgSend)(b,SELN("setTitle:forState:"),str(s),0);
}
static void cfgRefresh(void){
    gCfgValid=cfgRead();
    if(!gCfgValid){
        if(gCfgStatus)VOID1(gCfgStatus,"setText:",str("Chưa có cấu hình MinDo hợp lệ. INJECT bằng IPA trước."));
        setBtnTitle(gAimBtn,"Aim: —");setBtnTitle(gBoxBtn,"ESP Box: —");
        setBtnTitle(gLineBtn,"ESP Line: —");setBtnTitle(gBoneBtn,"ESP Bone: —");
        return;
    }
    if(gCfgStatus)VOID1(gCfgStatus,"setText:",str("Đã đọc bolacfg.bin • chỉnh trực tiếp trong game"));
    setBtnTitle(gAimBtn,(gCfg[7]&1)?"Aim: ON":"Aim: OFF");
    setBtnTitle(gBoxBtn,(gCfg[5]&1)?"ESP Box: ON":"ESP Box: OFF");
    setBtnTitle(gLineBtn,(gCfg[5]&2)?"ESP Line: ON":"ESP Line: OFF");
    setBtnTitle(gBoneBtn,(gCfg[7]&2)?"ESP Bone: ON":"ESP Bone: OFF");
}
static void cfgToggle(int which){
    // Read fresh bytes to avoid overwriting changes made by the original MinDo app.
    cfgRefresh();
    if(!gCfgValid)return;
    if(which==0){gCfg[7]^=1;if(gCfg[7]&1)gCfg[7]&=(unsigned char)~4u;} // Aim vs silent mutually exclusive
    if(which==1)gCfg[5]^=1;
    if(which==2)gCfg[5]^=2;
    if(which==3)gCfg[7]^=2;
    if(!cfgWrite()){
        if(gCfgStatus)VOID1(gCfgStatus,"setText:",str("Không ghi được cấu hình. Kiểm tra quyền truy cập."));
        return;
    }
    cfgRefresh();
}
static void actAim(id s,SEL c,id a){(void)s;(void)c;(void)a;cfgToggle(0);}
static void actBox(id s,SEL c,id a){(void)s;(void)c;(void)a;cfgToggle(1);}
static void actLine(id s,SEL c,id a){(void)s;(void)c;(void)a;cfgToggle(2);}
static void actBone(id s,SEL c,id a){(void)s;(void)c;(void)a;cfgToggle(3);}
static void togglePanel(id self,SEL cmd,id sender){(void)self;(void)cmd;(void)sender;BOOL1(gPanel,"setHidden:",0);BOOL1(gFloating,"setHidden:",1);cfgRefresh();}
static void closePanel(id self,SEL cmd,id sender){(void)self;(void)cmd;(void)sender;BOOL1(gPanel,"setHidden:",1);BOOL1(gFloating,"setHidden:",0);}
static void toggleFps(id self,SEL cmd,id sender){(void)self;(void)cmd;(void)sender;gShowFps=!gShowFps;((void(*)(id,SEL,id,long))objc_msgSend)(gFpsButton,SELN("setTitle:forState:"),str(gShowFps?"Tắt FPS":"Bật FPS"),0);VOID1(gFpsLabel,"setText:",str(gShowFps?"FPS UI: đang đo...":"FPS UI: đã tắt"));gFrames=0;gLast=0;}
static void toggleReticle(id self,SEL cmd,id sender){
    (void)self;(void)cmd;(void)sender;
    gShowReticle=!gShowReticle;
    BOOL1(gReticle,"setHidden:",!gShowReticle);
    ((void(*)(id,SEL,id,long))objc_msgSend)(gReticleButton,SELN("setTitle:forState:"),str(gShowReticle?"Tắt tâm ngắm":"Bật tâm ngắm"),0);
}
static void onFrame(id self,SEL cmd,id link){(void)self;(void)cmd;(void)link;if(!gShowFps)return;double now=CFAbsoluteTimeGetCurrent();if(!gLast){gLast=now;gFrames=0;return;}gFrames++;if(now-gLast>=1.){char buf[32];snprintf(buf,sizeof(buf),"FPS UI: %.0f",gFrames/(now-gLast));VOID1(gFpsLabel,"setText:",str(buf));gFrames=0;gLast=now;}}

static void initOverlay(void *unused){
    (void)unused;
    if(gWindow)return;
    if(gAttempts++>90)return; // Unity can take longer to create its scene on first launch
    id app=OBJ0(CLASS("UIApplication"),"sharedApplication");
    if(!app)goto retry;
    // An app can have non-window scenes. Pick a UIWindowScene explicitly.
    id scenes=OBJ0(OBJ0(app,"connectedScenes"),"allObjects");
    unsigned long sceneCount=((unsigned long(*)(id,SEL))objc_msgSend)(scenes,SELN("count"));
    id scene=NULL;
    for(unsigned long i=0;i<sceneCount;i++){
        id candidate=((id(*)(id,SEL,unsigned long))objc_msgSend)(scenes,SELN("objectAtIndex:"),i);
        int isWindow=((int(*)(id,SEL,id))objc_msgSend)(candidate,SELN("isKindOfClass:"),CLASS("UIWindowScene"));
        if(isWindow){scene=candidate;break;}
    }
    if(!scene)goto retry;
    // Only create a WindowScene-based overlay. Do not alter the game's key window.
    Class overlayClass=objc_getClass("MinDoRHWindow");
    if(!overlayClass){overlayClass=objc_allocateClassPair(objc_getClass("UIWindow"),"MinDoRHWindow",0);if(overlayClass){class_addMethod(overlayClass,SELN("hitTest:withEvent:"),(void*)hitTest,"@@:{CGPoint=dd}@");objc_registerClassPair(overlayClass);}}
    if(!overlayClass)goto retry;
    Class targetClass=objc_getClass("MinDoRHTarget");
    if(!targetClass){targetClass=objc_allocateClassPair(objc_getClass("NSObject"),"MinDoRHTarget",0);if(targetClass){class_addMethod(targetClass,SELN("openMenu:"),(void*)togglePanel,"v@:@");class_addMethod(targetClass,SELN("closeMenu:"),(void*)closePanel,"v@:@");class_addMethod(targetClass,SELN("toggleFPS:"),(void*)toggleFps,"v@:@");class_addMethod(targetClass,SELN("toggleReticle:"),(void*)toggleReticle,"v@:@");class_addMethod(targetClass,SELN("aimAction:"),(void*)actAim,"v@:@");class_addMethod(targetClass,SELN("boxAction:"),(void*)actBox,"v@:@");class_addMethod(targetClass,SELN("lineAction:"),(void*)actLine,"v@:@");class_addMethod(targetClass,SELN("boneAction:"),(void*)actBone,"v@:@");class_addMethod(targetClass,SELN("onFrame:"),(void*)onFrame,"v@:@");objc_registerClassPair(targetClass);}}
    if(!targetClass)goto retry;
    gTarget=OBJ0((id)targetClass,"new");
    gWindow=((id(*)(id,SEL,id))objc_msgSend)(OBJ0((id)overlayClass,"alloc"),SELN("initWithWindowScene:"),scene);
    if(!gWindow)goto retry;
    // A landscape game uses its scene's bounds; UIScreen bounds may be portrait.
    id coords=OBJ0(scene,"coordinateSpace");
    CGRect screenBounds=coords?bounds(coords):bounds(OBJ0(CLASS("UIScreen"),"mainScreen"));
    frame(gWindow,screenBounds);
    DOUBLE1(gWindow,"setWindowLevel:",2200.0);
    VOID1(gWindow,"setBackgroundColor:",color(0,0,0,0));
    id vc=OBJ0(CLASS("UIViewController"),"new");
    VOID1(gWindow,"setRootViewController:",vc);
    gRoot=OBJ0(vc,"view");
    VOID1(gRoot,"setBackgroundColor:",color(0,0,0,0));
    // Non-interactive center reticle, not auto-aim or target tracking.
    gReticle=label("+",rect((screenBounds.size.width-36)/2,(screenBounds.size.height-40)/2,36,40),34,color(1,.83,.22,1),1);
    LONG1(gReticle,"setAutoresizingMask:",29); // flexible margins keep center after rotation
    BOOL1(gReticle,"setUserInteractionEnabled:",0);
    BOOL1(gReticle,"setHidden:",1);
    VOID1(gRoot,"addSubview:",gReticle);

    gFloating=button("MinDo",rect(14,22,82,40),color(.06,.56,.63,.94),"openMenu:");
    VOID1(gRoot,"addSubview:",gFloating);
    double panelW=screenBounds.size.width-28;if(panelW>330)panelW=330;if(panelW<240)panelW=240;
    gPanel=view(rect(14,18,panelW,332),color(.06,.08,.12,.96),15);
    VOID1(gRoot,"addSubview:",gPanel);
    id white=color(.95,.97,1,1),subtle=color(.70,.76,.83,1);
    VOID1(gPanel,"addSubview:",label("MinDo • Menu trong game",rect(14,8,panelW-105,28),17,white,0));
    VOID1(gPanel,"addSubview:",label("Giao diện RootHide • thử nghiệm",rect(14,37,panelW-28,19),11,subtle,0));
    gFpsLabel=label("FPS UI: đang đo...",rect(14,62,panelW-28,24),15,white,0);
    VOID1(gPanel,"addSubview:",gFpsLabel);
    gFpsButton=button("Tắt FPS",rect(14,90,135,37),color(.11,.43,.56,1),"toggleFPS:");
    VOID1(gPanel,"addSubview:",gFpsButton);
    gReticleButton=button("Bật tâm ngắm",rect(14,134,135,37),color(.11,.43,.56,1),"toggleReticle:");
    VOID1(gPanel,"addSubview:",gReticleButton);
    id close=button("Thu gọn",rect(panelW-114,90,100,37),color(.36,.39,.48,1),"closeMenu:");
    VOID1(gPanel,"addSubview:",close);
    gCfgStatus=label("Kiểm tra bolacfg.bin...",rect(14,177,panelW-25,30),11,subtle,0);
    VOID1(gPanel,"addSubview:",gCfgStatus);
    double half=(panelW-40)/2;
    gAimBtn=button("Aim: —",rect(14,210,half,36),color(.13,.42,.57,1),"aimAction:");
    gBoxBtn=button("ESP Box: —",rect(26+half,210,half,36),color(.13,.42,.57,1),"boxAction:");
    gLineBtn=button("ESP Line: —",rect(14,253,half,36),color(.13,.42,.57,1),"lineAction:");
    gBoneBtn=button("ESP Bone: —",rect(26+half,253,half,36),color(.13,.42,.57,1),"boneAction:");
    VOID1(gPanel,"addSubview:",gAimBtn);VOID1(gPanel,"addSubview:",gBoxBtn);
    VOID1(gPanel,"addSubview:",gLineBtn);VOID1(gPanel,"addSubview:",gBoneBtn);
    VOID1(gPanel,"addSubview:",label("Chỉ điều khiển bản vá MinDo đã INJECT từ IPA.",rect(14,297,panelW-28,24),10,subtle,0));
    BOOL1(gPanel,"setHidden:",1);
    BOOL1(gWindow,"setHidden:",0);
    id display=((id(*)(id,SEL,id,SEL))objc_msgSend)(CLASS("CADisplayLink"),SELN("displayLinkWithTarget:selector:"),gTarget,SELN("onFrame:"));
    if(display){id loop=OBJ0(CLASS("NSRunLoop"),"mainRunLoop");((void(*)(id,SEL,id,id))objc_msgSend)(display,SELN("addToRunLoop:forMode:"),loop,str("NSRunLoopCommonModes"));}
    return;
retry:
    dispatch_after_f(dispatch_time(0, 1000000000LL),&_dispatch_main_q,NULL,initOverlay);
}

__attribute__((constructor)) static void entry(void){
    // Start on UI thread after Unity finishes creating the application scene.
    dispatch_after_f(dispatch_time(0, 3000000000LL),&_dispatch_main_q,NULL,initOverlay);
}
