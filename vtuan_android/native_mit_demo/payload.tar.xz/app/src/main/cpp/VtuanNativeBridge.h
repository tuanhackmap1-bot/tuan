#pragma once
namespace vtuan {
// False until the VTUAN key server validates an active, unexpired key.
// This is a rendering/function gating hook, NOT an ESP/AIM implementation.
bool authorized() noexcept;
}
