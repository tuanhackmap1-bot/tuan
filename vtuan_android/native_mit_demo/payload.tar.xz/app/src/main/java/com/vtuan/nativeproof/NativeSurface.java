package com.vtuan.nativeproof;
import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
public final class NativeSurface extends GLSurfaceView implements GLSurfaceView.Renderer {
    public static native void nativeInit();
    public static native void nativeResize(int w,int h);
    public static native void nativeFrame();
    public static native void nativeTouch(float x,float y,boolean pressed);
    public static native void nativeShutdown();
    public NativeSurface(Context context){
        super(context);
        setEGLContextClientVersion(3);
        setEGLConfigChooser(8,8,8,8,16,0);
        setRenderer(this);
        setRenderMode(RENDERMODE_CONTINUOUSLY);
    }
    @Override public void onSurfaceCreated(GL10 gl,EGLConfig config){nativeInit();}
    @Override public void onSurfaceChanged(GL10 gl,int w,int h){nativeResize(w,h);}
    @Override public void onDrawFrame(GL10 gl){nativeFrame();}
    @Override public boolean onTouchEvent(MotionEvent ev){
        final float x=ev.getX(),y=ev.getY();
        final boolean pressed=ev.getActionMasked()!=MotionEvent.ACTION_UP&&ev.getActionMasked()!=MotionEvent.ACTION_CANCEL;
        queueEvent(()->nativeTouch(x,y,pressed));
        return true;
    }
    @Override protected void onDetachedFromWindow(){queueEvent(NativeSurface::nativeShutdown);super.onDetachedFromWindow();}
}
